import React, { useState, useEffect } from "react"
import { Table , Image  } from 'react-bootstrap';

function App() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch("https://dummyjson.com/products")
      .then((response) => response.json())
      .then((data) => setProducts(data.products))
      .then((err) => console.log(err));
  }, [])

  console.log("products", products)



  return (
    <div className="container mt-5">
      <div className="d-flex justify-content-between mb-3">
        <h2>Products</h2>
      </div>
      <Table bordered>
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Product Description</th>
            <th>Product Image</th>
          </tr>
        </thead>
          <tbody>
            {products.map((products, index) => (
              <tr key={index}>
                <td style={{ width: "300px" }}>{products.title}</td>
                <td style={{ width: "600px" }}>{products.description}</td>
                <td style={{ width: "200px" }}>
                    <Image style={{ width: "50px" }}src={products.images}/>
                </td>
              </tr>
            ))}
            {products && products?.length === 0 && (
              <tr className="text-center">
                <td colSpan={12}>
                  <h4>No Record found.</h4>
                </td>
              </tr>
            )}
          </tbody>
      </Table>
    </div>
  )

}

export default App;